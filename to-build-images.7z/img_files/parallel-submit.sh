#!/bin/sh

/usr/hadoop-3.0.0/bin/hdfs namenode -format
/usr/hadoop-3.0.0/sbin/start-all.sh
/usr/hadoop-3.0.0/bin/hdfs dfs -put /tmp/input/ /input
