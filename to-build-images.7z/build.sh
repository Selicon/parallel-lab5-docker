#!/bin/sh

docker build -t "parallel/base" -f Dockerfile-base .
docker build -t "parallel/master" -f Dockerfile-master .
docker build -t "parallel/worker" -f Dockerfile-worker .
